'use strict'

class Validators {
    constructor(form) {
        this.patterns = {
            name: /^[a-zа-яё]+$/i,
            phone: /^\+7\(\d{3}\)\d{3}-\d{2}-\d{2}$/,
            email: /^[\w._-]+@\w+\.[a-z]{2,4}$/i
        };
        this.error = {

        }
        this.form = form;
        this.valid = false;
        this._validForm();
    }
    validate(regexp, value) {
        regexp.test(value);
    }

    _validForm() {
        let inputs = [...document.getElementById(this.form).getElementsByTagName('input')];
        for (field of inputs) {
            this._validate(field);
        }
        if (![...document.getElementById(this.form).querySelectorAll('.invalid')].length) {
            this.valid = true;
        }
    }

    _validate(field) {
        if (this.patterns[field.name]) {
            if (!this.patterns[field.name].test(field.value)) {
                field.classList.add('invalid');
            }
        }
    }


}